from functools import lru_cache
import multiprocessing
import time
import random
from collections import defaultdict
from constants import adjust_position_weight
from constants import BLACK, WHITE, EMPTY, opponent, EARLY_WEIGHTS, MID_WEIGHTS, LATE_WEIGHTS, CORNERS, X_SQUARES, C_SQUARES
from board import Board
import logging
logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(message)s', datefmt='%H:%M:%S')
import numpy as np
ZOBRIST_TABLE = np.random.randint(1, 2**63, size=(8, 8, 3), dtype=np.uint64)
def zobrist_hash(board):
    h = 0
    for i in range(8):
        for j in range(8):
            color = board.board[i][j]
            if color != EMPTY:
                h ^= ZOBRIST_TABLE[i][j][color]
    return h

def adjust_position_weight(pos, value, stages=('early', 'mid', 'late')):
    x, y = pos
    if 'early' in stages:
        for dx, dy in [(x, y), (7-x, y), (x, 7-y), (7-x, 7-y)]:
            EARLY_WEIGHTS[dx][dy] = value
    if 'mid' in stages:
        for dx, dy in [(x, y), (7-x, y), (x, 7-y), (7-x, 7-y)]:
            MID_WEIGHTS[dx][dy] = value
    if 'late' in stages:
        for dx, dy in [(x, y), (7-x, y), (x, 7-y), (7-x, 7-y)]:
            LATE_WEIGHTS[dx][dy] = value

class AdvancedAI:
    def __init__(self, color, difficulty='hard', time_limit=3.0):
        self.color = color
        self.difficulty = difficulty
        self.time_limit = time_limit
        self.transposition_table = {}
        self.killer_moves = defaultdict(list)
        self.history_table = defaultdict(int)
        self.nodes_searched = 0
        for corner in CORNERS:
            adjust_position_weight(corner, 300)

        for x in X_SQUARES:
            adjust_position_weight(x, -90)

        for c in C_SQUARES:
            adjust_position_weight(c, -40, stages=('mid',))
        # Difficulty settings - 더 현실적인 설정
        if difficulty == 'easy':
            self.max_depth = 4
            self.time_limit = 100.0
        elif difficulty == 'medium':
            self.max_depth = 6
            self.time_limit = 120.0
        else:  # hard
            self.max_depth =  7
            self.time_limit = 500.0  # 60초는 너무 길어서 15초로 조정
        
    def get_weights_for_stage(self, board):
        """Get evaluation weights based on game stage"""
        empty_count = board.get_empty_count()
        if empty_count > 45:
            return EARLY_WEIGHTS
        elif empty_count > 20:
            return MID_WEIGHTS
        else:
            return LATE_WEIGHTS
    
    @lru_cache(maxsize=10000)
    def evaluate_board(self, board):
        try:
            if board.get_empty_count() == 0:
                b, w = board.count_stones()
                diff = (b - w) if self.color == BLACK else (w - b)
                return 10000 * (1 if diff > 0 else -1 if diff < 0 else 0)

            empty_count = board.get_empty_count()
            stage_weights = self.get_game_stage_weights(empty_count)

            scores = {
                'positional': self.evaluate_positional(board),
                'mobility': self.evaluate_mobility(board),
                'stability': self.evaluate_stability(board),
                'corner': self.evaluate_corners(board),
                'frontier': self.evaluate_frontier(board),
                'parity': self.evaluate_parity(board)
            }

            total_score = sum(stage_weights[key] * scores[key] for key in scores)
            return total_score
        except Exception as e:
            print(f"AI evaluation error: {str(e)}")
            return 0

    
    def solve_endgame(self, board, color):
        valid_moves = self.get_valid_moves(board, color)
        if not valid_moves:
            opponent_moves = self.get_valid_moves(board, 3 - color)
            if not opponent_moves:
                return board.count_score(color), None
            return self.solve_endgame(board, 3 - color)
        best_score = float('-inf')
        best_move = None
        for move in valid_moves:
            new_board = board.apply_move(*move, color)
            score, _ = self.solve_endgame(new_board, 3 - color)
            score = -score
            if score > best_score:
                best_score = score
                best_move = move
        return best_score, best_move
    def get_game_stage_weights(self, empty_count):
        """Get weights for different evaluation components based on game stage"""
        if empty_count > 45:  # Early game
            return {
                'positional': 0.4, 'mobility': 1.0, 'stability': 0.2,
                'corner': 1.5, 'frontier': -0.3, 'parity': 0.1
            }
        elif empty_count > 20:  # Mid game
            return {
                'positional': 0.7, 'mobility': 0.8, 'stability': 0.6,
                'corner': 1.2, 'frontier': -0.2, 'parity': 0.3
            }
        else:  # End game
            return {
                'positional': 0.3, 'mobility': 0.3, 'stability': 0.8,
                'corner': 0.5, 'frontier': -0.1, 'parity': 1.0
            }

    def evaluate_positional(self, board):
        """Evaluate positional advantage"""
        weights = self.get_weights_for_stage(board)
        score = 0
        
        for i in range(8):
            for j in range(8):
                if board.board[i][j] == self.color:
                    score += weights[i][j]
                elif board.board[i][j] == opponent(self.color):
                    score -= weights[i][j]
        
        # Dynamic penalty for dangerous squares near empty corners
        for corner_x, corner_y in CORNERS:
            if board.board[corner_x][corner_y] == EMPTY:
                # Penalize X-squares and C-squares near empty corners
                dangerous_squares = [(corner_x + dx, corner_y + dy) 
                                   for dx, dy in [(1, 1), (0, 1), (1, 0)] 
                                   if 0 <= corner_x + dx < 8 and 0 <= corner_y + dy < 8]
                
                for x, y in dangerous_squares:
                    if board.board[x][y] == self.color:
                        score -= 25
                    elif board.board[x][y] == opponent(self.color):
                        score += 25
        
        return score

    def evaluate_mobility(self, board):
        """Evaluate mobility (number of possible moves)"""
        my_moves = len(board.get_valid_moves(self.color))
        opp_moves = len(board.get_valid_moves(opponent(self.color)))
        
        if my_moves + opp_moves == 0:
            return 0
        
        # Relative mobility
        mobility_score = 100 * (my_moves - opp_moves) / (my_moves + opp_moves + 1)
        
        # Bonus for having moves when opponent doesn't
        if my_moves > 0 and opp_moves == 0:
            mobility_score += 50
        elif my_moves == 0 and opp_moves > 0:
            mobility_score -= 50
            
        return mobility_score

    def evaluate_stability(self, board):
        """Evaluate disc stability"""
        my_stable = 0
        opp_stable = 0
        
        for i in range(8):
            for j in range(8):
                if board.board[i][j] == self.color and board.is_stable(i, j):
                    my_stable += 1
                elif board.board[i][j] == opponent(self.color) and board.is_stable(i, j):
                    opp_stable += 1
                    
        return 25 * (my_stable - opp_stable)

    def evaluate_corners(self, board):
        """Evaluate corner control"""
        my_corners = sum(1 for x, y in CORNERS if board.board[x][y] == self.color)
        opp_corners = sum(1 for x, y in CORNERS if board.board[x][y] == opponent(self.color))
        
        corner_score = 25 * (my_corners - opp_corners)
        
        # Exponential bonus for multiple corners
        if my_corners > 1:
            corner_score += 10 * my_corners * my_corners
        if opp_corners > 1:
            corner_score -= 10 * opp_corners * opp_corners
            
        return corner_score

    def evaluate_frontier(self, board):
        """Evaluate frontier discs (fewer is better)"""
        my_frontier = board.get_frontier_count(self.color)
        opp_frontier = board.get_frontier_count(opponent(self.color))
        return opp_frontier - my_frontier

    def evaluate_parity(self, board):
        """Evaluate disc count parity"""
        b, w = board.count_stones()
        diff = (b - w) if self.color == BLACK else (w - b)
        return diff

    def sort_moves(self, board, moves, depth):
        """Sort moves for better alpha-beta pruning - 성능 최적화"""
        move_scores = []
        
        for move in moves:
            x, y = move
            score = 0
            
            # Killer moves bonus
            if move in self.killer_moves.get(depth, []):
                score += 1000
                
            # History heuristic
            score += self.history_table.get(move, 0)
            
            # Strategic position values (빠른 평가)
            if move in CORNERS:
                score += 500
            elif move in X_SQUARES:
                # 간단한 코너 체크 (성능 최적화)
                adjacent_corner_occupied = any(
                    board.board[corner[0]][corner[1]] != EMPTY
                    for corner in CORNERS
                    if abs(corner[0] - x) <= 1 and abs(corner[1] - y) <= 1
                )
                if not adjacent_corner_occupied:
                    score -= 200
            elif move in C_SQUARES:
                score -= 100
            elif x == 0 or x == 7 or y == 0 or y == 7:  # Edge
                score += 50
            
            # 무거운 연산들 제거 (apply_move 호출 없음)
            # 대신 간단한 휴리스틱 사용
            # 중앙 근처면 점수 추가
            center_dist = abs(x - 3.5) + abs(y - 3.5)
            score += (7 - center_dist) * 2
            
            move_scores.append((score, move))
            
        move_scores.sort(reverse=True)
        return [move for _, move in move_scores]

    def alphabeta(self, board, depth, alpha, beta, maximizing, start_time):
        """Alpha-beta pruning with enhancements"""
        self.nodes_searched += 1
        board_hash = zobrist_hash(board)
        # 시간 제한 체크를 더 관대하게 - 90% 사용 후 체크
        if time.time() - start_time > self.time_limit:
            return self.evaluate_board(board), None
        
        # Transposition table lookup
        board_hash = board.get_hash()
        if board_hash in self.transposition_table:
            entry = self.transposition_table[board_hash]
            if entry['depth'] >= depth:
                return entry['score'], entry['move']
        
        current_color = self.color if maximizing else opponent(self.color)
        moves = board.get_valid_moves(current_color)
        
        # Terminal node or max depth reached
        if depth == 0 or not moves:
            if not moves:
                # No moves available - check if opponent can move
                opponent_moves = board.get_valid_moves(BLACK if current_color == WHITE else WHITE)
                if not opponent_moves:
                    # Game over
                    return self.evaluate_board(board), None
                else:
                    # Pass turn
                    return self.alphabeta(board, depth, alpha, beta, not maximizing, start_time)
            else:
                return self.evaluate_board(board), None
        
        # Sort moves for better pruning
        sorted_moves = self.sort_moves(board, moves, depth)
        best_move = None
        
        if maximizing:
            max_score = float('-inf')
            for move in sorted_moves:
                new_board = board.apply_move(*move, current_color)
                score, _ = self.alphabeta(new_board, depth - 1, alpha, beta, False, start_time)
                
                if score > max_score:
                    max_score = score
                    best_move = move
                    
                alpha = max(alpha, score)
                if beta <= alpha:
                    # Beta cutoff - save killer move
                    if len(self.killer_moves[depth]) >= 2:
                        self.killer_moves[depth].pop(0)
                    self.killer_moves[depth].append(move)
                    break
                    
            # Update history table
            if best_move:
                self.history_table[best_move] += depth * depth
                
            # Store in transposition table
            self.transposition_table[board_hash] = {
                'score': max_score, 'move': best_move, 'depth': depth
            }
            return max_score, best_move
            
        else:
            min_score = float('inf')
            for move in sorted_moves:
                new_board = board.apply_move(*move, current_color)
                score, _ = self.alphabeta(new_board, depth - 1, alpha, beta, True, start_time)
                
                if score < min_score:
                    min_score = score
                    best_move = move
                    
                beta = min(beta, score)
                if beta <= alpha:
                    if len(self.killer_moves[depth]) >= 2:
                        self.killer_moves[depth].pop(0)
                    self.killer_moves[depth].append(move)
                    break
                    
            if best_move:
                self.history_table[best_move] += depth * depth
                
            self.transposition_table[board_hash] = {
                'score': min_score, 'move': best_move, 'depth': depth
            }
            return min_score, best_move

    def iterative_deepening(self, board):
        """Iterative deepening search without early cutoff"""
        start_time = time.time()
        best_move = None
        last_completed_depth = 0 
        moves = board.get_valid_moves(self.color)
        if not moves:
            return None

        if len(moves) == 1:
            return moves[0]
        
        logging.info(f"[고정깊이 탐색 모드] 탐색 시작: max_depth={self.max_depth}, 가능한 수={len(moves)}개")
        
        for depth in range(1, self.max_depth + 1):
            try:
                self.nodes_searched = 0  # 깊이별 노드 카운트 초기화
                depth_start_time = time.time()
                logging.info(f"깊이 {depth} 탐색 시작...")
                
                _, move = self.alphabeta(board, depth, float('-inf'), float('inf'), True, start_time)
                depth_time = time.time() - depth_start_time
                
                if move:
                    best_move = move
                last_completed_depth = depth

                logging.info(f"깊이 {depth} 완료: {depth_time:.2f}s, 노드: {self.nodes_searched}, 최적수: {move}")

            except Exception as e:
                logging.info(f"깊이 {depth}에서 예외 발생: {e}")
                import traceback
                logging.info(f"예외 상세: {traceback.format_exc()}")
                break

        logging.info(f"[고정깊이 탐색 완료] depth={last_completed_depth}, nodes_searched={self.nodes_searched}, time={time.time()-start_time:.2f}s")        
        return best_move


    def get_strategic_opening_move(self, board):
        """전략적 오프닝 수 - 단순한 휴리스틱이 아닌 실제 평가"""
        moves = board.get_valid_moves(self.color)
        if not moves:
            return None
            
        # 초반에도 미니 탐색 수행 (깊이 4-6)
        opening_depth = min(6, self.max_depth)
        best_move = None
        best_score = float('-inf')
        
        logging.info(f"초반수 전략적 탐색 시작 (깊이: {opening_depth})")
        
        for move in moves:
            new_board = board.apply_move(*move, self.color)
            # 미니 알파베타 탐색
            score, _ = self.alphabeta(new_board, opening_depth - 1, float('-inf'), float('inf'), False, time.time())
            
            # X-스퀘어와 C-스퀘어에 대한 추가 페널티
            x, y = move
            if move in X_SQUARES:
                # 인접 코너가 비어있으면 큰 페널티
                for corner in CORNERS:
                    if abs(corner[0] - x) <= 1 and abs(corner[1] - y) <= 1:
                        if board.board[corner[0]][corner[1]] == EMPTY:
                            score -= 50
                            break
            elif move in C_SQUARES:
                score -= 20
            
            if score > best_score:
                best_score = score
                best_move = move
                
        logging.info(f"초반수 전략적 선택: {best_move}, 점수: {best_score}")
        return best_move

    def get_move(self, board):
        """Get the best move for current position"""
        self.nodes_searched = 0
        
        # 초반 30수 이하에서도 전략적 사고 적용 (기존 50 -> 30으로 변경)
        if board.get_empty_count() > 54:  # 처음 10수 정도만 간단한 전략적 오프닝
            return self.get_strategic_opening_move(board)
        
        # Use iterative deepening for main search
        return self.iterative_deepening(board)
    def _alphabeta_worker(self, args):
        board, move, depth, color = args
        new_board = board.apply_move(*move, color)
        score, _ = self.alphabeta(new_board, depth - 1, float('-inf'), float('inf'), False, time.time())
        return score, move

    def get_best_move(self, board):
        empty = board.get_empty_count()
        if empty <= 12:
            _, move = self.solve_endgame(board, self.color)
            return move

        moves = board.get_valid_moves(self.color)
        if not moves:
            return None

        args_list = [(board, move, self.max_depth, self.color) for move in moves]
        with multiprocessing.Pool() as pool:
            results = pool.map(self._alphabeta_worker, args_list)

        best_score, best_move = max(results, key=lambda x: x[0])
        return best_move