import tkinter as tk
from gui import OthelloGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = OthelloGUI(root)
    root.mainloop()



